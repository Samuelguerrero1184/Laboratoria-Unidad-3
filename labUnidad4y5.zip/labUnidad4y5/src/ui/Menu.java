package ui;

import java.text.DecimalFormat;
import java.util.*;

import model.*;
public class Menu {
	private static Scanner sc;
	private static CarDealer carDealer;
	private static DecimalFormat myFormatter;
	
	/**
	* Initialize all variables  <br>
	* <b> pre: </b> variables must be created in class <br>
	* <b> post: </b> the variables are initialized, and create the objects.
	*
	*/
	public static void initialize(){
		carDealer = new CarDealer("AutoVenta", 123456789, 0, 0);
		SalesMan s1 = new SalesMan("Samuel", "Guerrero", 1127227665, 0, 0);
		SalesMan s2 = new SalesMan("Maria", "Viveros", 29434545, 0, 0);
		SalesMan s3 = new SalesMan("Pablo", "Villamil", 131231311, 0, 0);
		SalesMan s4 = new SalesMan("Alvaro", "Guerrero", 323124252, 0,0);
		SalesMan s5 = new SalesMan("Isabella", "Rodriguez", 99999999, 0,0);
		SalesMan s6 = new SalesMan("Alberto", "Garces", 354354034, 0,0);
		SalesMan s7 = new SalesMan("Manuel", "Beltran", 724947197, 0,0);
		SalesMan s8 = new SalesMan("Sebastian", "Gay", 24656456, 0,0);
		SalesMan s9 = new SalesMan("Lorena", "Martinez", 425346446, 0,0);
		SalesMan s10 = new SalesMan("Felipe", "Tronco", 646648646, 0,0);
		
		carDealer.addSeller(s1);
		carDealer.addSeller(s2);
		carDealer.addSeller(s3);
		carDealer.addSeller(s4);
		carDealer.addSeller(s5);
		carDealer.addSeller(s6);
		carDealer.addSeller(s7);
		carDealer.addSeller(s8);
		carDealer.addSeller(s9);
		carDealer.addSeller(s10);
		

		
		ElectricCar ec2 = new ElectricCar(0, 60000000, "Lamborghini"
				, 2018, 2200, 50000, true, "MHQ-064", "CAMIONETA", 4, false, "RAPIDO", 50);
		
		ElectricCar ec3 = new ElectricCar(0, 100000000, "Nissan"
				, 2018, 2200, 80000, true, "CMM-111", "CAMIONETA", 4, false, "RAPIDO", 50);
		
		ElectricCar ec4 = new ElectricCar(0, 95000000, "Kia"
				, 2012, 2200, 0, false, "KIA-256", "SEDAN", 4, false, "RAPIDO", 50);
		PetrolCar gc1 = new PetrolCar(0, 80000000, "Ferrari"
				, 2013, 2000, 0, false, "GHY-289", 2, false, "EXTRA", 75);
		
		ElectricCar ec1 = new ElectricCar(0, 65000000, "Audi"
				, 2020, 1600, 0, false, "CPY-256", "SEDAN", 4, true, "RAPIDO", 50);
		
		PetrolCar gc3 = new PetrolCar(0, 90000000, "Porsche"
				, 2014, 2200, 7000, true, "TYU-765", 4, true, "CORRIENTE", 50);
		
		PetrolCar gc5 = new PetrolCar(0, 30000000, "Chevrolet"
				, 2020, 1600, 0, false, "ADF-890", 4, true, "DIESEL", 50);
		
		PetrolCar gc4 = new PetrolCar(0, 30000000, "Mazda"
				, 2019, 2000, 20000, true, "CAMIONETA", 4, true, "DIESEL", 80);
		
		Motorcycle m1 = new Motocycle(0, 5000000, "AKT"
				, 2013, 2000, 0, false,  "ESTANDAR", 8);
		
		Motorcycle m2 = new Motocycle(0, 20000000, "DUCATTI"
				, 2013, 2000, 0, false, "ESTANDAR", 8);
	
		carDealer.addVehicle(ec4);
		carDealer.addVehicle(ec2);
		carDealer.addVehicle(ec3);
		carDealer.addVehicle(gc1);
		carDealer.addVehicle(ec1);
		carDealer.addVehicle(gc3);
		carDealer.addVehicle(gc4);
		carDealer.addVehicle(gc5);
		carDealer.addVehicle(m1);
		carDealer.addVehicle(m2);
		carDealer.addVehicle(h1);
		carDealer.addVehicle(h2);
		
		  sc = new Scanner(System.in);
		  myFormatter = new DecimalFormat("###,###.###");
		
	}
	/**
	* will show on console the menu<br>
	* <b>pre: </b>  <br>
	* <b>post: </b> The user has been informed of the options they have.
	*/	
	public static void menu() {
		System.out.println("_-_-_-Menu_-_-_-");
		System.out.println("Selecione una opcion");
		System.out.println("(1) CREAR cliente");
		System.out.println("(2) MOSTRAR informacion clientes");
		System.out.println("(3) MOSTRAR informacion asesores de venta y sus respectivos clientes");	
		System.out.println("(4) MOSTRAR vehiculos de interes y sus datos");
		System.out.println("(5) Vehiculos");	
		System.out.println("(6) Catalogo usados y nuevos");	
		System.out.println("(7) AGREGAR un vehiculo");	
		System.out.println("(8) VENDER vehiculo");	
		System.out.println("(9) MOSTRAR ventas totales");	
		System.out.println("(10) Estado de parqueo");
		System.out.println("(11) INFO de parqueo");
		System.out.println("(12) EXIT");
	}
	
	public void startProgram(){
		initialize();	
		int x= 0;
		while(x !=12){
			menu();
			x = sc.nextInt();
			switch (x) {
				case 1:
					readClient();
					break;
				case 2:
					ShowClients();
					break;
				case 3:
					ShowSellers();
					break;
				case 4:
					ShowVehicles();
					break;
				case 5:
					CatalogTypeVehicle();
					break;
				case 6:
					catalogoUsedVehicles();
					break;
				case 7:
					ReadVehicle();
					break;
				case 8:
					createSale();
					break;
				case 9:
					totalProfitEnterprice();
					break;
				case 10:
					updateParking();
					break;
				case 11:
					infoparkingmenu();
					break;
					
			}
		}
	}
	

	public void infoParkingMenu() {
		System.out.println(carDealer.getInfoParking());
	}
		
	/**
	* will show on the screen the information of the every vehicle<br>
	* <b>pre: </b> variables must be created in class  <br>
	* <b>post: </b> The user has been informed of the options they have and show in screen.
	*/
	public void CatalogTypeVehicle() {
		int x = 0;
		while (x != 5) {
		System.out.println("Que desea agregar\n (1) CARRO A GASOLINA\n (2) CARRO ELECTRICO\n (3) CARRO HIBRIDO\n (4) MOTO\n (5) SALIR");
		sc.nextLine();
		int option = sc.nextInt();
		x = option;
		System.out.println(carDealer.getInfoTypeVehicle(option));
		}
	}
	/**
	* will show on the screen the information of the every vehicle<br>
	* <b>pre: </b> variables must be created in class  <br>
	* <b>post: </b> The user has been informed of the options they have and show in screen.
	*/
	public void catalogoUsedVehicles() {
		int x = 0;
		while (x != 4) {
		System.out.println("Que desea ver?\n 1) VEHICULOS USADOS\n 2 )VEHICULOS NUEVOS\n 3 )TODOS\n 4 )SALIR");
		sc.nextLine();
		int option = sc.nextInt();
		x = option;
		System.out.println(carDealer.infoIfUsed(option));
		}
	}
	/**
	* Create a new client and add in the carDelaer<br>
	* <b>pre: </b> variables must be created in class  <br>
	* <b>post: </b> create a new client an add in the carDealer.
	*/
	public void readClient() {
		System.out.println("Digita el Nombre del Nuevo cliente");
		sc.nextLine();
		String nameClient = sc.nextLine();
		System.out.println("Digita el apellido del cliente");
		String lastNane = sc.nextLine();
		System.out.println("digita la cedula del cliente");
		int cedula = sc.nextInt();
		sc.nextLine();
		System.out.println("Digita el telefono del cliente");
		int phone = sc.nextInt();
		sc.nextLine();
		System.out.println("Digita el correo electronico del cliente");
		String email = sc.nextLine();
		System.out.println("Digita el numero que corresponde al asesor de venta\n");
		String cd = carDealer.ShowSalesManNames();
		System.out.println(cd);
		sc.hasNextLine();
		int seller = sc.nextInt();
		
		Clients newClient = new Clients(nameClient, lastNane, cedula, phone, email);
		carDealer.getSeller(seller).addClient(newClient);
	}
	/**
	* Show clients and his information <br>
	* <b>pre: </b> variables must be created in class  <br>
	* <b>post: </b> Show clients and his information and show on console.
	*/
		public void ShowClients() {
		System.out.println(carDealer.infoClients());
		}
		/**
		* Show client and his information <br>
		* <b>pre: </b> variables must be created in class  <br>
		* <b>post: </b> Show clients and his information and show on console.
		* @param a the selection variable of the index. a != null.
		*/
		public void ShowClients(int a ) {
		System.out.println(carDealer.infoClients(a));
		}
		/**
		* Show sellers and his information <br>
		* <b>pre: </b> variables must be created in class  <br>
		* <b>post: </b> Show sellers and his information and show on console.
		*/
		public void ShowSellers() {
			System.out.println(carDealer.infoSellers());
		}
		/**
		* Show vehicles and his information <br>
		* <b>pre: </b> variables must be created in class  <br>
		* <b>post: </b> Show vehicles and his information and show on consolen.
		*/
		public void ShowVehicles() {
			System.out.println(carDealer.infoVehicles());
			
		}
		/**
		* Create a new vehicle and add in the carDealer<br>
		* <b>pre: </b> variables must be created in class  <br>
		* <b>post: </b> create a new vehicle an add in the carDealer.
		*/
		public void ReadVehicle() {
			System.out.println("Que tipo de vehiculo va a ingresar:");
			System.out.println("(1) gasolina");
			System.out.println("(2) Electrico");
			System.out.println("(3) hibrido");
			System.out.println("(4) Moto");
			int option = sc.nextInt();
			System.out.println("marca del vehiculo");
			String mark = sc.nextLine();
			sc.nextLine();
			System.out.println("precio base de el vehiculo");
			float price = sc.nextInt();
			sc.nextLine();
			System.out.println("modelo del vehiculo");
			
			int model = sc.nextInt();
			sc.nextLine();
			System.out.println("cilindraje del vehiculo");
			int cilindraje = sc.nextInt();
			sc.nextLine();
			System.out.println("kilometraje del vehiculo");
			int mileaje = sc.nextInt();
			sc.nextLine();
			System.out.println("si el vehicluo es usado ingrese uno, de lo contrario culauqier tecla");
			int usedString = sc.nextInt();
			boolean used = false;
			if(usedString == 1) {
				used = true;
			}else{
				used = false;
			}
			System.out.println("Digita la placa del vehiculo");
			String placa = sc.nextLine();
			sc.nextLine();
			if (option == 1 || option == 2 || option == 3) {
				System.out.println("Digita el tipo de vehiculo (Sedan o Camioneta)");
				String type = sc.nextLine();
				
				System.out.println("Digita la cantidad de puertas del vehiculo");
				int numberOfDoors = sc.nextInt();
				sc.nextLine();
				System.out.println("Digita 1 si el auto es polarizado o  digita 0 si no lo es");
				int polarizadoint = sc.nextInt();
				boolean polar = false;
				if(polarizadoint == 1) {
					polar = true;
				}else{
					polar = false;
				}
					switch (option){
							case 1:
								System.out.println("Digita el tipo de gasolina que usa el vehiculo\n EXTRA\n CORRIENTE\n DIESEL");
								sc.nextLine();
								String gasolineType = sc.nextLine();
								System.out.println("Digita la capacidad del tanque");
								int gasolineCapacity = sc.nextInt();
								sc.nextLine();
								PetrolCar newGasolineCar = new PetrolCar(0, price, mark
										, model, cilindraje, mileaje, used, placa, type, numberOfDoors, polar, gasolineType, gasolineCapacity);
								carDealer.addVehicle(newGasolineCar);
								
								break;
							case 2:
								System.out.println("Escribe el tipo de cargador que usa el vehiculo\n RAPIDO\n NORMAL");
								sc.nextLine();
								String ChargerType = sc.nextLine();
								System.out.println("Digita la autonomia de la bateria en Kwatts");
								int batteryLife = sc.nextInt();
								sc.nextLine();
								ElectricCar newElectricCar = new ElectricCar(0, price, mark
										, model, cilindraje, mileaje, used, placa, type, numberOfDoors, 
										polar, ChargerType, batteryLife);
								carDealer.addVehicle(newElectricCar);
								
							case 3:
								System.out.println("Escribe el tipo de cargador que usa el vehiculo\n RAPIDO\n NORMAL");
								sc.nextLine();
								String a = sc.nextLine();
								System.out.println("Digita la autonomia de la bateria en kwatts");
								int b = sc.nextInt();
								sc.nextLine();
								System.out.println("Digita el tipo de gasolina que usa el vehiculo\n EXTRA\n CORRIENTE\n DIESEL");
								sc.nextLine();
								String c = sc.nextLine();
								System.out.println("Digita la capacidad del tanque");
								int d = sc.nextInt();
								sc.nextLine();
								HybridCar newHibritCar = new HybridCar(0, price, mark
										, model, cilindraje, mileaje, used, placa, type, numberOfDoors, 
										polar, a, b,c, d);
								carDealer.addVehicle(newHibritCar);

			}
					
		}
			else if (option == 4) {
				System.out.println("Escriba el tipo de motocicleta\n ESTANDAR\n DEPORTIVA\n SCOOTER\n SCOOTER");
				String typeM = sc.nextLine();
				sc.nextLine();
				System.out.println("Digita la capacidad del tanque");
				int gasolineCapacitym = sc.nextInt();
				Motorcycle newMotorcycle = new Motorcycle(0, price, mark
						, model, cilindraje, mileaje, used, placa,typeM,gasolineCapacitym);
				carDealer.addVehicle(newMotorcycle);
			}
		}

		
		/**
		* Create a new sale and Show information of this<br>
		* <b>pre: </b> variables must be created in class  <br>
		* <b>post: </b> create a new sale and show information.
		*/
	
		public void createSale() {
			String infoSale = "La informacion de la venta es:\n";
			ShowSellers();
			System.out.println("Digita que vendedor que Asesoro");			
			int seller = sc.nextInt();
			ShowClients(seller);
			System.out.println("Digita que cliente va a hacer la compra");
			int client = sc.nextInt();
			Clients Client = carDealer.getSeller(seller).getClient(client);
			infoSale += "\ninformacionn del cliente \n " + Clients.infoClient() + "\n";	
			ShowVehicles();
			System.out.println("Digita que Vehiculo deseas comprar");
			int vehicle = sc.nextInt();
			Vehicles Vehicle = carDealer.getVehicle(vehicle);
			infoSale += "\n La informacion completa del vehiculo comprado es ===" + Vehicle.basicInfo() + "\n";	
			infoSale += "Nombre del asesor de venta ===" + carDealer.getSeller(seller).getName() + "\n";
			infoSale += "Valor Total Venta: " + myFormatter.format(lVehicle.getSalesPrice());
			int total = (int) (carDealer.getTotalProfit() + (int)Vehicle.getSalesPrice());
			carDealer.setTotalProfit(total);
			carDealer.getVehicle(vehicle).setSoldStatus(true);
			System.out.println(infoSale);
			
			/**
			* Show total Profit of the carDealer <br>
			* <b>pre: </b> variables must be created in class  <br>
			* <b>post: </b>  Show total Profit of the carDealer and show on console.
			*/	
		}
		public void totalProfitEnterprice() {
			System.out.println("Las ventas totales de la empresa son :\n");
			System.out.println(myFormatter.format(carDealer.getTotalProfit()));
		}
		
		
	}
