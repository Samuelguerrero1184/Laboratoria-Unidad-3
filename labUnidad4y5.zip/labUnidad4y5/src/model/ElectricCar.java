package model;

import java.util.ArrayList;

public class ElectricCar extends Vehicles{
	
	private static int vehicleModel;
	private String ChargerType;
	private int batteryLife;
	private double batteryConsumption;
	 /** 
	 * will transform the parameters into a variables of this class and create type of object <br> 
	 * <b>pre: </b>the parameters cannot be null<br> 
	 * <b>post: </b>transform the parameter to a variable of this class and made a object. 
	 * @param vehiclePrice variable for vehicles totalPrice. vehiclePrice != null. 
	 * @param vehicleBasePrice variable for vehicles BasePrice. vehicleBasePrice !=null.
	 * @param vehicleBrand variable for vehicles vehicleBrand. vehicleBrand !=null.
	 * @param vehicleModel variable for vehicles vehicleModel. vehicleModel !=null.
	 * @param vehicleCc variable for vehicles vehicleCc. vehicleCc !=null.
	 * @param vehicleMileage variable for vehicles vehicleMileage. vehicleMileage !=null.
	 * @param vehicleNew variable for vehicles vehicleNew. used !=null.
	 * @param vehicleType variable for vehicles vehicleType. vehicleType !=null.
	 * @param vehicleDoors variable for vehicles number Of vehicleDoors. vehicleDoors !=null.
	 * @param tintedWindows variable for vehicles tintedWindows. tintedWindows !=null.
	 * @param ChargerType variable for vehicles Charger Type. ChargerType !=null.
	 * @param batteryLife variable for vehicles battery Life. batteryLife !=null.
	 */	
	public ElectricCar(float totalPrice, float BasePrice, String mark, int model, int cilindraje, int mileaje, boolean used, String placa, String type, int numberOfDoors, boolean polarizado, String ChargerType, int batteryLife) {
		super(vehiclePrice, vehicleBasePrice, vehicleBrand, vehicleModel, vehicleCc, vehicleMileage, vehicleNew, vehicleType, vehicleDoors, tintedWindows);
		this.ChargerType = ChargerType;
		this.batteryLife = batteryLife;
		setAdicionalCost (0.2);
		setUsedDiscount (0.1);
  }
	 /** 
 	 * get the element that you selected<br> 
 	 * <b>pre: </b>the variable to return must be entered <br> 
 	 * <b>post: </b>get the object selected.
 	 * @return chargeType. 
 	 */	
	public String getChargerType() {
		return ChargerType;
	}
	 /** 
	 * will transform the parameter into a variable of this class <br> 
	 * <b>pre: </b>The required parameter cannot be null <br> 
	 * <b>post: </b>transform the parameter to a variable of this class. 
	 * @param chargerType the selection variable of the charger Type. chargerType != null. 
	 */
	public void setChargerType(String chargerType) {
		this.ChargerType = chargerType;
	}
	 /** 
 	 * get the element that you selected<br> 
 	 * <b>pre: </b>the variable to return must be entered <br> 
 	 * <b>post: </b>get the object selected.
 	 * @return batteryConsume. 
 	 */	
	public double getBatteryConsume() {
		return batteryConsumption;
	}
	 /** 
	 * will transform the parameter into a variable of this class <br> 
	 * <b>pre: </b>The required parameter cannot be null <br> 
	 * <b>post: </b>transform the parameter to a variable of this class. 
	 * @param batteryConsume the selection variable of the battery Consume. batteryConsume != null. 
	 */
	public void setBatteryConsume(double batteryConsumption) {
		this.batteryConsumption = batteryConsumption;
	}
	 /** 
 	 * get the element that you selected<br> 
 	 * <b>pre: </b>the variable to return must be entered <br> 
 	 * <b>post: </b>get the object selected.
 	 * @return batteryLife. 
 	 */	
	public int getBatteryLife() {
		return batteryLife;
	}
	 /** 
	 * will transform the parameter into a variable of this class <br> 
	 * <b>pre: </b>The required parameter cannot be null <br> 
	 * <b>post: </b>transform the parameter to a variable of this class. 
	 * @param batteryLife the selection variable of the battery Life. batteryLife != null. 
	 */
	public void setBatteryLife(int batteryLife) {
		this.batteryLife = batteryLife;
	}
	
	  /** 
	  * Accumulates the data in a chain of information <br> 
	  * <b>pre: </b>The required parameter cannot be null <br> 
	  * <b>post: </b>returns a string of accumulated information. 
	  * @return basicInfo. 
	  */
	  @Override
	  public String basicInfo() {
		String basicInfo = super.basicInfo();
		 basicInfo+="\nTipo de cargador: " +getChargerType() +  "\nCapacidad de bateria: " +  getBatteryLife() + 
				 "\nConsumo de bateria por kilometro: " +  getBatteryConsume();
		 return basicInfo;
	  }
}