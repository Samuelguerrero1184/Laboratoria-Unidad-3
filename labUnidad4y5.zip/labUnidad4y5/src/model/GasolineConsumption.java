package model;

public interface GasolineConsumption {
	public double calculateGasolineConsume (int gasolineCapacity, int cilindraje);

}