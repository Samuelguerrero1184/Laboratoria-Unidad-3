package model;

public class HybridCar {

}
