package model;

import java.util.ArrayList;

public class PetrolCar extends Vehicles implements GasolineConsumption{
	
	private String vehicleGasType;
	private int vehicleGasCapacity; 
	private double vehicleGasConsumption;
	public final static int EXTRA = 1;
	public final static int CORRIENTE = 2;
	public final static int DIESEL = 3;
    
	 /** 
	 * will modify each parameter into a variables of this class creating its object <br> 
	 * <b>pre: </b>the parameters cannot be null<br> 
	 * <b>post: </b>transform the parameter to a variable of this class and made a object. 
	 * @param vehiclePrice the selection variable of the vehiclePrice. vehiclePrice != null. 
	 * @param vehicleBasePrice the selection variable of the vehicleBasePrice. vehicleBasePrice !=null.
	 * @param vehicleBrand the selection variable of the vehiclebrand.vehiclebrand !=null.
	 * @param vehiclemodel the selection variable of the vehiclemodel. vehiclemodel !=null.
	 * @param vehiclecc the selection variable of the vehiclecc. vehiclecc !=null.
	 * @param vehiclemileage the selection variable of the vehiclemileage. vehiclemileage !=null.
	 * @param vehiclenew the selection variable of the vehiclenew. vehiclenew !=null.
	 * @param vehicletype the selection variable of the vehicletype. vehicletype !=null.
	 * @param vehicleDoors the selection variable of the number Of Doors. vehicleDoors !=null.
	 * @param tintedWindows the selection variable of the tintedWindows.tintedWindows !=null.
	 * @param vehiclegasolineType the selection variable of the gasoline Type. vehiclegasolineType !=null.
	 * @param vehiclegasolineCapacity the selection variable of the  vehiclegasolineCapacity. vehiclegasolineCapacity !=null.
	 */	
	
	public PetrolCar (int vehiclePrice, int vehicleBasePrice, String vehicleBrand, int vehicleModel, int vehicleCc, int vehicleMileage, boolean vehicleNew, String vehicleType, int vehicleDoors,boolean tintedWindows, String vehicleGasolineType, int vehicleGasolineCapacity) {
		
		super(vehiclePrice, vehicleBasePrice, Brand, vehicleModel, vehicleCc, vehicleMileage, vehicleNew, vehicleType, vehicleDoors, tintedWndows);
		this.vehicleGasType = vehicleGasType;
		this.vehicleGasCapacity = vehicleGasCapacity;
		this.vehicleGasConsumption = calculateGasolineConsume(vehicleGasolineCapacity, vehicleCc);
		setAdicionalCost (0);
		setUseddiscount ( 0.1);
  }
	 /** 
 	 * get the element that you selected<br> 
 	 * <b>pre: </b>the variable to return must be entered <br> 
 	 * <b>post: </b>get the object selected.
 	 * @return vehiclegasType. 
 	 */	
	public String getGasType() {
		return vehicleGasType;
	}

	 /** 
	 * will transform the parameter into a variable of this class <br> 
	 * <b>pre: </b>The required parameter cannot be null <br> 
	 * <b>post: </b>transform the parameter to a variable of this class. 
	 * @param vehiclegasType the selection variable of the vehiclegasType. vehiclegasType != null. 
	 */
	public void setGasType(String vehicleGasType) {
		this.vehicleGasType = vehicleGasType;
	}

	 /** 
 	 * get the element that you selected<br> 
 	 * <b>pre: </b>the variable to return must be entered <br> 
 	 * <b>post: </b>get the object selected.
 	 * @return vehiclegasCapacity. 
 	 */	
	public int getGasCapacity() {
		return vehicleGasCapacity;
	}

	 /** 
	 * will transform the parameter into a variable of this class <br> 
	 * <b>pre: </b>The required parameter cannot be null <br> 
	 * <b>post: </b>transform the parameter to a variable of this class. 
	 * @param vehiclegasCapacity the selection variable of the vehiclegasCapacity. vehiclegasCapacity != null. 
	 */
	public void setGasCapacity(int vehicleGasCapacity) {
		this.vehicleGasCapacity = vehicleGasCapacity;
	}

	 /** 
 	 * get the element that you selected<br> 
 	 * <b>pre: </b>the variable to return must be entered <br> 
 	 * <b>post: </b>get the object selected.
 	 * @return gasConsumption. 
 	 */	
	public double getGasConsumption() {
		return vehicleGasConsumption;
	}

	 /** 
	 * will transform the parameter into a variable of this class <br> 
	 * <b>pre: </b>The required parameter cannot be null <br> 
	 * <b>post: </b>transform the parameter to a variable of this class. 
	 * @param vehiclegasConsumption the selection variable of the vehiclegasConsume. vehiclegasConsume != null. 
	 */
	public void setGasConsumption(double gasolineConsume) {
		this.vehicleGasConsumption = vehicleGasConsumption;
	}

	/** 
	* Modify a variable and return the modified variable <br> 
	* <b>pre: </b>The required parameter cannot be null <br> 
	* <b>post: </b>Return the modified variable. 
	* @return vehiclegasConsumption.
	* @param vehiclegasCapacity the selection variable of the vehiclegasCapacity. vehiclegasCapacity != null.
	* @param vehicleCc the selection variable of the vehicleCc . vehicleCc  != null.  
	*/
	@Override
	public double calculateGasConsumption(int vehicleGasCapacity, int vehicleCc) {
		vehicleGasConsumption = getGasCapacity()*(getCc()/100);
		return vehicleGasConsumption;
		
	}
	/** 
	* Accumulates the data in a chain of information <br> 
	* <b>pre: </b>The required parameter cannot be null <br> 
	* <b>post: </b>returns a string of accumulated information. 
	* @return basicInfo. 
	*/
	  @Override
	  public String basicInfo() {
		String basicInfo = super.basicInfo();
		 basicInfo+="\nTipo de gasolina: " +getGasType() +  "\nCapacidad de gasolina: " +  getGasCapacity() + 
				 "\nConsumo de gasolina por kilometro: " +  getGasConsumption();
		 return basicInfo;
	  }
  
}