package model;

public class Tecno {
	private int TecnoPrice;
	private int TecnoYear;
	private int TecnoCodeZ;
	
	public int getTecnoPrice() {
		return TecnoPrice;
	}
	public void setTecnoPrice(int tecnoPrice) {
		TecnoPrice = tecnoPrice;
	}
	public int getTecnoYear() {
		return TecnoYear;
	}
	public void setTecnoYear(int tecnoYear) {
		TecnoYear = tecnoYear;
	}
	public int getTecnoCodeZ() {
		return TecnoCodeZ;
	}
	public void setTecnoCodeZ(int tecnoCodeZ) {
		TecnoCodeZ = tecnoCodeZ;
	}
	
}
