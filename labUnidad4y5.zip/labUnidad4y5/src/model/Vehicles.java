package model;

import java.util.ArrayList;

public class Vehicles {
	protected int vehiclePrice;
	protected int vehicleBasePrice;
	protected String vehicleBrand;
	protected int vehicleModel;
	protected int vehicleCc;
	protected int vehicleMileage;
	protected boolean vehicleNew;
	protected boolean vehicleSOAT;
	protected boolean vehicleTecno;
	protected  String vehicleType;
	protected int vehicleDoors;
	protected boolean tintedWindows;
	private double adicionalCost;
	private double usedDiscount;
	private boolean soldStatus;
    
	public Vehicles(int vehiclePrice, int vehicleBasePrice, String vehicleBrand, int vehicleModel, int vehicleCc,
			int vehicleMileage, boolean vehicleNew, boolean vehicleSOAT, boolean vehicleTecno) {
		
		this.vehiclePrice = vehiclePrice;
		this.vehicleBasePrice = vehicleBasePrice;
		this.vehicleBrand = vehicleBrand;
		this.vehicleModel = vehicleModel;
		this.vehicleCc = vehicleCc;
		this.vehicleMileage = vehicleMileage;
		this.vehicleNew = vehicleNew;
	}
	
	public Vehicles(int vehiclePrice, int vehicleBasePrice, String vehicleBrand, int vehicleModel, int vehicleCc,
			int vehicleMileage, boolean vehicleNew, boolean vehicleSOAT, boolean vehicleTecno, String vehicleType,
			int vehicleDoors, boolean tintedWindows) {
		
		this.vehiclePrice = vehiclePrice;
		this.vehicleBasePrice = vehicleBasePrice;
		this.vehicleBrand = vehicleBrand;
		this.vehicleModel = vehicleModel;
		this.vehicleCc = vehicleCc;
		this.vehicleMileage = vehicleMileage;
		this.vehicleNew = vehicleNew;
		this.vehicleSOAT = vehicleSOAT;
		this.vehicleTecno = vehicleTecno;
		this.vehicleType = vehicleType;
		this.vehicleDoors = vehicleDoors;
		this.tintedWindows = tintedWindows;
	}
	
	public int getVehiclePrice() {
		return vehiclePrice;
	}
	public void setVehiclePrice(int vehiclePrice) {
		this.vehiclePrice = vehiclePrice;
	}
	public int getVehicleBasePrice() {
		return vehicleBasePrice;
	}
	public void setVehicleBasePrice(int vehicleBasePrice) {
		this.vehicleBasePrice = vehicleBasePrice;
	}
	public String getVehicleBrand() {
		return vehicleBrand;
	}
	public void setVehicleBrand(String vehicleBrand) {
		this.vehicleBrand = vehicleBrand;
	}
	public int getVehicleModel() {
		return vehicleModel;
	}
	public void setVehicleModel(int vehicleModel) {
		this.vehicleModel = vehicleModel;
	}
	public int getVehicleCc() {
		return vehicleCc;
	}
	public void setVehicleCc(int vehicleCc) {
		this.vehicleCc = vehicleCc;
	}
	public int getVehicleMileage() {
		return vehicleMileage;
	}
	public void setVehicleMileage(int vehicleMileage) {
		this.vehicleMileage = vehicleMileage;
	}
	public boolean isVehicleNew() {
		return vehicleNew;
	}
	public void setVehicleNew(boolean vehicleNew) {
		this.vehicleNew = vehicleNew;
	}
	public boolean isVehicleSOAT() {
		return vehicleSOAT;
	}
	public void setVehicleSOAT(boolean vehicleSOAT) {
		this.vehicleSOAT = vehicleSOAT;
	}
	public boolean isVehicleTecno() {
		return vehicleTecno;
	}
	public void setVehicleTecno(boolean vehicleTecno) {
		this.vehicleTecno = vehicleTecno;
	}
	
	/** 
	Stores the data of vehicles <br> 
	<b>pre: </b>The required parameter cannot be null <br> 
	<b>post: </b>returns a string of accumulated information. 
 	@return basicInfo. 
	*/
	public String basicInfo() {
		String basicInfo = "Marca: " +getVehicleBrand() +  "\nModelo: " + getVehicleModel() + "\nCilindraje: "
	+ getVehicleCc() + "\nkilometraje: " + getVehicleMileage()+ "\nUsado: " + isVehicleNew()+ "\nPrecio Base: " + getVehicleBasePrice()+ "\nPrecio Total: " + getVehiclePrice();
		  return basicInfo;
	}   
	 /** 
	 * will transform the parameter into a variable of this class <br> 
	 * <b>pre: </b>The required parameter cannot be null <br> 
	 * <b>post: </b>transform the parameter to a variable of this class. 
	 * @param placa the selection variable of the placa. placa!= null. 
	 */
	public void setAdicionalCost(double add) {
		this.adicionalCost = add;
	}

	 /** 
	 * will transform the parameter into a variable of this class <br> 
	 * <b>pre: </b>The required parameter cannot be null <br> 
	 * <b>post: </b>transform the parameter to a variable of this class. 
	 * @param placa the selection variable of the placa. placa!= null. 
	 */
	public void setUseddiscount(double dis) {
		this.usedDiscount = dis;
	}
	 /** 
	 * get the element that you selected<br> 
	 * <b>pre: </b>the variable to return must be entered <br> 
	 * <b>post: </b>get the object selected.
	 * @return Sales Price. 
	 */	
	public double getSalesPrice() {
		double price;
		price = getVehicleBasePrice() * (1 + adicionalCost);
		if (getUsed()) {price =  price * (1 - usedDiscount);}
		

		return price;
	}
	 private boolean getUsed() {
		// TODO Auto-generated method stub
		return false;
	}

	/** 
	 * get the element that you selected<br> 
	 * <b>pre: </b>the variable to return must be entered <br> 
	 * <b>post: </b>get the object selected.
	 * @return soldStatus. 
	 */	
	public boolean getSoldStatus() {
		return soldStatus;
	}
	 /** 
	 * will transform the parameter into a variable of this class <br> 
	 * <b>pre: </b>The required parameter cannot be null <br> 
	 * <b>post: </b>transform the parameter to a variable of this class. 
	 * @param soldStatus the selection variable of the soldStatus. soldStatus != null. 
	 */
	public void setSoldStatus(boolean soldStatus) {
		this.soldStatus = soldStatus;
	}
    

}

