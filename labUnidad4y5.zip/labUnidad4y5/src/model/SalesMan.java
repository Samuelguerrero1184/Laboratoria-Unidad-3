package model;

	import java.util.ArrayList;

	public class SalesMan {
	private String SalesManName;
	private String SalesManLname;
	private int Id;
	private int TotalSales;
	private int clientsAmount;
	private ArrayList<Clients> salesClients;
	final public int MAXCLIENTS = 5;

	/** 
	* will transform the parameters into a variables of this class and create type of object <br> 
	* <b>pre: </b> the parameters cannot be null<br> 
	* <b>post: </b>transform the parameter to a variable of this class and create a object. 
	* @param name the selection variable of the name. name!= null. 
	* @param lastName the selection variable of the lastName. lastName!=null.
	* @param cedula the selection variable of the cedula. cedula!=null.
	* @param salesQuantity the selection variable of the sales Quantity. salesQuantity != null. 
	*/
	
	public SalesMan(String SalesManName, String SalesManLname, int Id, int TotalSales,int clientsAmount) {
		this.SalesManName = SalesManName;
		this.SalesManLname = SalesManLname;
		this.Id = Id;
		this.TotalSales = TotalSales;
		this.clientsAmount = clientsAmount;
		sellerClients = new ArrayList<Clients>();
	}
	
	/** 
	* Add an item to a list<br> 
	* <b>pre: </b>The required parameter cannot be null <br> 
	* <b>post: </b>transform the parameter to a variable of this class and add to a list. 
	* @param client the selection object of the client. client != null. 
	*/
	public void addClient(Clients client) {
		if(salesClients.size()!=MAXCLIENTS)
		salesClients.add(client);
		else System.out.println("No se puede agregar mas clientes a este vendedor");
	}
	 /** 
		 * get the element that you selected<br> 
		 * <b>pre: </b>the variable to return must be entered <br> 
		 * <b>post: </b>get the object selected.
		 * @return name. 
		 */	
	public String getName() {
		return SalesManName;
	}
	/** 
	* will transform the parameter into a variable of this class <br> 
	* <b>pre: </b>The required parameter cannot be null <br> 
	* <b>post: </b>transform the parameter to a variable of this class. 
	* @param name the selection variable of the name. name != null. 
	*/
	public void setName(String SalesManName) {
		this.SalesManName = SalesManName;
	}
	 /** 
		 * get the element that you selected<br> 
		 * <b>pre: </b>the variable to return must be entered <br> 
		 * <b>post: </b>get the object selected.
		 * @return lastName. 
		 */	
	public String getLastName() {
		return SalesManLname;
	}
	/** 
	* will transform the parameter into a variable of this class <br> 
	* <b>pre: </b>The required parameter cannot be null <br> 
	* <b>post: </b>transform the parameter to a variable of this class. 
	* @param lastName the selection variable of the last Name. lastName != null. 
	*/
	public void setLastName(String SalesManLname) {
		this.SalesManLname = SalesManLname;
	}
	 /** 
		 * get the element that you selected<br> 
		 * <b>pre: </b>the variable to return must be entered <br> 
		 * <b>post: </b>get the object selected.
		 * @return cedula. 
		 */	
	public int getId() {
		return Id;
	}
	/** 
	* will transform the parameter into a variable of this class <br> 
	* <b>pre: </b>The required parameter cannot be null <br> 
	* <b>post: </b>transform the parameter to a variable of this class. 
	* @param cedula the selection variable of the cedula. cedula != null. 
	*/
	public void setId(int Id) {
		this.Id = Id;
	}
	 /** 
		 * get the element that you selected<br> 
		 * <b>pre: </b>the variable to return must be entered <br> 
		 * <b>post: </b>get the object selected.
		 * @return clientsCuantity. 
		 */	
	public int getClientsAmount() {
		return clientsAmount;
	}
	/** 
	* will transform the parameter into a variable of this class <br> 
	* <b>pre: </b>The required parameter cannot be null <br> 
	* <b>post: </b>transform the parameter to a variable of this class. 
	* @param clientsCuantity the selection variable of the clients Cuantity. clientsCuantity != null. 
	*/
	public void setClientsAmount( int clientsAmount) {
		this.clientsAmount = clientsAmount;
	}
	 /** 
		 * get the element that you selected<br> 
		 * <b>pre: </b>the variable to return must be entered <br> 
		 * <b>post: </b>get the object selected.
		 * @return salesQuantity. 
		 */	
	public int getTotalSales() {
		return TotalSales;
	}
	/** 
	* will transform the parameter into a variable of this class <br> 
	* <b>pre: </b>The required parameter cannot be null <br> 
	* <b>post: </b>transform the parameter to a variable of this class. 
	* @param salesQuantity the selection variable of the sales Quantity. salesQuantity != null. 
	*/
	public void setTotalSales(int TotalSales) {
		this.TotalSales = TotalSales;
	}
	/** 
	* Accumulates the data in a chain of information <br> 
	* <b>pre: </b>The required parameter cannot be null <br> 
	* <b>post: </b>returns a string of accumulated information. 
	* @return infoSeller. 
	*/
	public String infoSalesMan() {
		String infoSalesMan = "Nombre: " +getName() +  "\nApellido: " + getLastName() + "\nCedula: "
	+ getId() +  "\nCantidad de ventas: " + getTotalSales();
		String  clients = "\nLos clientes que fueron asesorados:\n";
		for (int i = 0; i <salesClients.size() ; i++) {
			clients += salesClients.get(i).getSalesManName()+"\n";
			
	}
		infoSalesMan += clients;
		return infoSalesMan;
	}

	/** 
	* get the object that you selected<br> 
	* <b>pre: </b>the variable to return must be entered <br> 
	* <b>post: </b>get the object selected.
	* @return clients.get(index). 
	*/	
	public Clients getClient(int index) {
		return salesClients.get(index);	
	}

	/** 
	* get the arraylist that you selected<br> 
	* <b>pre: </b>the variable to return must be entered <br> 
	* <b>post: </b>get the object selected.
	* @return clients. 
	*/	
	public ArrayList<Clients> getClients() {
		return sellerClients;	
	}
	 
	}
